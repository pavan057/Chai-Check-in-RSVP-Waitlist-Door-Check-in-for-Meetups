# ☕ Chai Check-in

**Turn messy RSVPs into a clean guest list, a fair waitlist, a fast door check-in and balanced teams — for meetups, build nights and club events.**

I run *Chai & Commits*, a 40-seat build night in Hyderabad. RSVPs arrive as WhatsApp messages, form rows and DMs. People RSVP twice, cancel in the group chat, show up unannounced, and at 6 PM someone has to split the room into teams. I was doing all of that by hand in a spreadsheet. This app does it for me.

![Tonight view](docs/screenshot-tonight.png)

## What it does

| Step | What happens |
|---|---|
| **Import** | Paste a WhatsApp chat export, a Google Forms CSV, or one person per line. Duplicates merge (by email → phone → name), "can't make it / cancel" messages free the seat, chatter is ignored. A preview shows exactly what will change before anything is saved. |
| **Seats** | First come, first served up to capacity. RSVPs after the deadline are kept but queued behind everyone who made it. Cancel someone and the next person on the waitlist moves up automatically. |
| **Message** | Pre-written confirmation and waitlist texts, one-tap *Open in WhatsApp*, bulk copy. The app tracks who has been told — and flags people whose status changed since. |
| **Door** | Big search box: type a few letters or the last digits of a phone number, press Enter. Waitlisted arrivals get a prompt showing free seats. Walk-ins in one tap. |
| **Teams** | Mixed-role teams (design, frontend, backend, AI/ML…) dealt snake-style from whoever actually showed up. Shuffle, move people, add late arrivals, copy the list for the group chat. |
| **Undo** | Every change shows an Undo toast. Backups download as JSON. |

Optional ✨ **Gemini parsing** for very messy text: add your own key from [Google AI Studio](https://aistudio.google.com/apikey) in Settings. The key stays in your browser and is sent only to Google. Everything else works offline.

## Privacy

No server, no accounts. All data lives in your browser's `localStorage`. Nothing leaves the device unless you turn on Gemini parsing.

## Run locally

```bash
npm install
npm run dev      # http://localhost:5173
npm test         # parser, seat and team rules
npm run build
```

## Deploy on GitHub Pages (free)

1. Push this folder to a new GitHub repo on the `main` branch.
2. In the repo go to **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. The included workflow (`.github/workflows/deploy.yml`) runs the tests, builds and publishes to
   `https://<your-username>.github.io/<repo-name>/`.

## Built with

React 18 · TypeScript · Vite · Vitest · Gemini API (optional). No UI library — hand-written CSS in an Irani-café palette, light and dark mode, mobile-first door view.

## How it was built

Planned with Gemini and vibe-coded as part of the Handshake × Google **Vibe Code an App** mission. The full build prompt, the rules I set, and the bugs I fixed along the way are in [`PROMPT.md`](PROMPT.md).

## License

MIT
