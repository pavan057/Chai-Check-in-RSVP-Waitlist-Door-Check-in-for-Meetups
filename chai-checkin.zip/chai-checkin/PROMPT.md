# Build prompt & debugging log

## The task
I organize a 40-seat build night. Every event I spend hours turning WhatsApp RSVPs into a spreadsheet, chasing duplicates and cancellations, messaging the waitlist, checking people in at the door and splitting the room into teams by hand.

**Inputs → process → output → goal**
My RSVP messages (WhatsApp export / form CSV / plain list) → de-duplicate, apply cancellations, allocate seats first-come-first-served with a waitlist → a live roster, pre-written messages, a door check-in screen and balanced teams → so the event runs on time and nobody gets forgotten.

## Build prompt (pasted into Google AI Studio → Build)

> Build a mobile-friendly web app called **Chai Check-in** for a meetup organizer.
>
> **Import:** a big paste box that accepts a WhatsApp chat export (iOS `[dd/mm/yy, h:mm AM] Name: msg` and Android `dd/mm/yyyy, HH:mm - Name: msg`), a Google Forms CSV, or one person per line. Extract name, email, 10-digit Indian phone and role (frontend, backend, full-stack, design, AI/ML, other). Skip chatter like questions. Messages saying "cancel / can't make it" cancel that person. Always show a preview table (New / Updates info / Cancels / Already in list) with checkboxes before saving. Add an optional "Preview with Gemini" button that uses the organizer's own API key.
>
> **Rules:**
> 1. Never create duplicates — match by email, then phone, then name.
> 2. Seats are first come, first served up to capacity (default 40).
> 3. RSVPs after the deadline are kept but go behind every on-time RSVP.
> 4. A cancellation automatically promotes the next waitlisted person.
> 5. Walk-ins checked in at the door are always seated.
> 6. Never invent emails or phone numbers.
>
> **Screens:** Tonight (event signboard, stats, a seat map drawn as chai glasses, a run-sheet checklist), Import, Roster (search, filters, per-person message preview with Copy and Open in WhatsApp, cancel/restore, notes, CSV export), Door (large search, Enter checks in a single match, confirm dialog for waitlisted people, one-tap walk-in), Teams (team size stepper, mixed-role teams, shuffle, move members, copy for group chat), Settings (event details, capacity, deadline, Gemini key, backup/restore, clear data).
>
> **Style:** Irani café — beige #F3E3C3, chai brown #6B3E26, teal #1F7A74, signal red #C8412B; display serif for headings, monospace for contact details; dark mode; bottom tab bar on phones.
>
> Store everything in localStorage. Show a welcome tour for first-time visitors and a "try with sample data" option. Every destructive action gets an Undo toast.

## Debugging log (what broke → the fix → the standing rule)

| Found while testing | Fix | Rule kept from then on |
|---|---|---|
| Sender "+91 99887 76655" produced the name "Rahul Engineer" | Strip job words (engineer, developer, dev…) and filler before guessing a name | Names never contain role words |
| A question in the chat ("what time does it start?") became an attendee | Only accept WhatsApp lines that look like an RSVP, a cancellation, or contain contact details | Chatter is never imported |
| Importing the same chat twice doubled the list | Merge by email → phone → name, fill in missing fields instead of adding | Importing is idempotent |
| "Message everyone" showed as done as soon as RSVPs existed | Track the status each person was last told about; flag "needs update" when it changes | A step is only done when it's actually done |
| On phones the bottom tab bar rendered at the top | The header's `backdrop-filter` made it the containing block for the fixed nav; removed it on mobile | Test every screen at 390 px wide |
| Status tags got cut off next to long names on phones | Moved tags into their own flex line that never shrinks | Labels never truncate; names do |

Tests for the parser, seat allocation and team balancing live in `src/parse.test.ts` and run on every deploy.
