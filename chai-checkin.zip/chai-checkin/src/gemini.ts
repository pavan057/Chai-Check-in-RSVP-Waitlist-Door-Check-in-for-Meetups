import type { ParsedRsvp, Role } from './types';
import { ROLES } from './types';
import { normalizePhone } from './parse';

/**
 * Optional: ask Gemini to extract RSVPs from text the offline parser can't handle
 * (e.g. a messy DM thread). Uses the organizer's own API key from Google AI Studio;
 * the key stays in this browser's localStorage and is sent only to Google.
 */
export async function parseWithGemini(text: string, key: string, model: string): Promise<ParsedRsvp[]> {
  const prompt = `You extract event RSVPs from messy messages.
Return one entry per distinct person. Rules:
- name: the person's name as written (Title Case). If only a phone number is known, use "".
- email / phone: only if literally present; never invent. Phone = 10-digit Indian mobile if present.
- role: one of ${ROLES.join(', ')} based on what they say they do; "other" if unclear.
- rsvpAt: ISO 8601 timestamp if the message has one, else "".
- cancel: true only if the person says they can no longer attend.
Ignore general chatter, questions, and messages from the organizer.

Messages:
"""
${text.slice(0, 30000)}
"""`;

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: 'ARRAY',
            items: {
              type: 'OBJECT',
              properties: {
                name: { type: 'STRING' },
                email: { type: 'STRING' },
                phone: { type: 'STRING' },
                role: { type: 'STRING', enum: ROLES },
                rsvpAt: { type: 'STRING' },
                cancel: { type: 'BOOLEAN' },
              },
              required: ['name', 'email', 'phone', 'role', 'rsvpAt', 'cancel'],
            },
          },
        },
      }),
    },
  );
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    if (res.status === 400 && /API key/i.test(body)) throw new Error('Gemini rejected the API key. Check it in Settings.');
    if (res.status === 404) throw new Error(`Model "${model}" wasn't found. Pick another model in Settings.`);
    if (res.status === 429) throw new Error('Gemini rate limit reached. Wait a minute and try again, or use the offline parser.');
    throw new Error(`Gemini request failed (${res.status}).`);
  }
  const data = await res.json();
  const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!raw) throw new Error('Gemini returned an empty answer. Try the offline parser.');
  const items = JSON.parse(raw) as Array<Record<string, unknown>>;
  return items.map((i) => {
    const t = String(i.rsvpAt ?? '');
    const d = t ? new Date(t) : null;
    const role = ROLES.includes(i.role as Role) ? (i.role as Role) : 'other';
    return {
      name: String(i.name ?? '').trim(),
      email: String(i.email ?? '').trim().toLowerCase(),
      phone: normalizePhone(String(i.phone ?? '')),
      role,
      rsvpAt: d && !isNaN(d.getTime()) ? d.toISOString() : null,
      cancel: Boolean(i.cancel),
    };
  }).filter((p) => p.name || p.email || p.phone);
}
