import { useEffect, useState } from 'react';
import type { Role, SeatStatus } from './types';

export const ROLE_LABEL: Record<Role, string> = {
  frontend: 'Frontend', backend: 'Backend', fullstack: 'Full-stack',
  design: 'Design', 'ai/ml': 'AI / ML', other: 'Builder',
};

export function RoleChip({ role }: { role: Role }) {
  return <span className={`chip role-${role.replace('/', '')}`}>{ROLE_LABEL[role]}</span>;
}

export function StatusChip({ status, pos, late }: { status: SeatStatus; pos?: number | null; late?: boolean }) {
  const label = status === 'confirmed' ? 'Seated' : status === 'waitlist' ? `Waitlist #${pos}` : 'Cancelled';
  return (
    <span className="chip-row">
      <span className={`chip status-${status}`}>{label}</span>
      {late && status !== 'cancelled' && <span className="chip late" title="RSVP'd after the deadline">Late</span>}
    </span>
  );
}

export function Cup({ state, title }: { state: 'empty' | 'held' | 'here' | 'walkin'; title?: string }) {
  return (
    <span className={`cup cup-${state}`} title={title} aria-label={title}>
      <svg viewBox="0 0 32 32" aria-hidden="true">
        {state === 'here' || state === 'walkin' ? (
          <g className="steam">
            <path d="M11 9c-2-2 2-3 0-5" /><path d="M16 9c-2-2 2-3 0-5" /><path d="M21 9c-2-2 2-3 0-5" />
          </g>
        ) : null}
        <path className="glass" d="M7 12h18l-2 15a2 2 0 0 1-2 2H11a2 2 0 0 1-2-2z" />
        {state !== 'empty' && <path className="tea" d="M8.2 16h15.6l-1.4 10.8a1.5 1.5 0 0 1-1.5 1.2H11.1a1.5 1.5 0 0 1-1.5-1.2z" />}
      </svg>
    </span>
  );
}

export function initials(name: string) {
  return name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase() || '?';
}

export function Avatar({ name }: { name: string }) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return <span className="avatar" style={{ background: `hsl(${h} 45% 38%)` }}>{initials(name)}</span>;
}

export interface ToastMsg { id: number; text: string; undo?: () => void }

export function Toast({ toast, onDone }: { toast: ToastMsg | null; onDone: () => void }) {
  const [shown, setShown] = useState(toast);
  useEffect(() => {
    setShown(toast);
    if (!toast) return;
    const t = setTimeout(onDone, toast.undo ? 6000 : 3500);
    return () => clearTimeout(t);
  }, [toast, onDone]);
  if (!shown) return null;
  return (
    <div className="toast" role="status">
      <span>{shown.text}</span>
      {shown.undo && <button className="link-btn" onClick={() => { shown.undo!(); onDone(); }}>Undo</button>}
    </div>
  );
}

export async function copyText(text: string) {
  try { await navigator.clipboard.writeText(text); return true; }
  catch {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    const ok = document.execCommand('copy'); ta.remove(); return ok;
  }
}
