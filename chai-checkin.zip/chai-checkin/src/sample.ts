// Fictional sample chat used only by the "Try with sample RSVPs" button.
export const SAMPLE_CHAT = `[12/10/26, 9:02 AM] Ananya Rao: Count me in! ananya.rao@example.com, frontend (React)
[12/10/26, 9:05 AM] Kiran Kumar: RSVP - backend dev, 98480 12345
[12/10/26, 9:07 AM] Sneha: Hey what time does it start?
[12/10/26, 9:15 AM] Sneha Reddy: I'm in, UI/UX designer, sneha.r@example.com
[12/10/26, 10:40 AM] +91 99887 76655: Rahul here, ML engineer, rahul.m@example.com count me in
[13/10/26, 8:20 PM] Farhan Ali: I'm in — full stack, farhan@example.com
[13/10/26, 8:22 PM] Ananya Rao: also my number is 90000 11122
[14/10/26, 11:00 AM] Divya S: interested! figma + frontend, divya.s@example.com
[15/10/26, 6:45 PM] Kiran Kumar: sorry guys can't make it anymore, cancel for me
[22/10/26, 7:10 AM] Arjun Varma: RSVP please, backend, arjun.v@example.com`;
