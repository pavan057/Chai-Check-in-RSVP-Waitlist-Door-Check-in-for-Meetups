import type { Attendee, EventSettings, ParsedRsvp, RosterRow } from './types';
import { identityKeys } from './parse';

export const uid = () => Math.random().toString(36).slice(2, 10);

export function isLate(a: Attendee, s: EventSettings): boolean {
  if (!s.deadline || a.walkIn) return false;
  const dl = new Date(s.deadline).getTime();
  return !isNaN(dl) && new Date(a.rsvpAt).getTime() > dl;
}

/**
 * Seat rule (first come, first served):
 *  - cancelled people never hold a seat
 *  - on-time RSVPs are seated in order, late RSVPs go behind all on-time ones
 *  - the first `capacity` get seats, everyone else is waitlisted in order
 *  - walk-ins who were checked in at the door are always confirmed
 * Because this is computed, a cancellation automatically promotes the next person.
 */
export function buildRoster(attendees: Attendee[], s: EventSettings): RosterRow[] {
  const active = attendees.filter((a) => !a.cancelled);
  const sorted = [...active].sort((a, b) => {
    const la = isLate(a, s) ? 1 : 0;
    const lb = isLate(b, s) ? 1 : 0;
    if (la !== lb) return la - lb;
    return a.order - b.order;
  });
  const walkIns = sorted.filter((a) => a.walkIn);
  const queue = sorted.filter((a) => !a.walkIn);
  const seatsLeft = Math.max(0, s.capacity - walkIns.length);

  const rows: RosterRow[] = [];
  queue.forEach((a, i) => {
    const confirmed = i < seatsLeft || a.checkedInAt !== null;
    rows.push({ ...a, status: confirmed ? 'confirmed' : 'waitlist', late: isLate(a, s), waitlistPos: null, needsMessage: false });
  });
  let pos = 1;
  for (const r of rows) if (r.status === 'waitlist') r.waitlistPos = pos++;
  walkIns.forEach((a) => rows.push({ ...a, status: 'confirmed', late: false, waitlistPos: null, needsMessage: false }));
  attendees
    .filter((a) => a.cancelled)
    .forEach((a) => rows.push({ ...a, status: 'cancelled', late: isLate(a, s), waitlistPos: null, needsMessage: false }));
  // Walk-ins and people already at the door don't need a text.
  for (const r of rows) r.needsMessage = r.status !== 'cancelled' && !r.walkIn && !r.checkedInAt && (r.messagedStatus ?? null) !== r.status;
  return rows;
}

export interface MergeResult {
  attendees: Attendee[];
  added: number;
  updated: number;
  cancelled: number;
  skipped: number;
}

/** Merge parsed RSVPs into the existing list without creating duplicates. */
export function mergeRsvps(existing: Attendee[], parsed: ParsedRsvp[]): MergeResult {
  const list = existing.map((a) => ({ ...a }));
  const index = new Map<string, Attendee>();
  const reindex = (a: Attendee) => identityKeys(a).forEach((k) => index.set(k, a));
  list.forEach(reindex);
  let order = list.reduce((m, a) => Math.max(m, a.order), -1) + 1;
  let added = 0, updated = 0, cancelled = 0, skipped = 0;

  for (const p of parsed) {
    const match = identityKeys(p).map((k) => index.get(k)).find(Boolean);
    if (match) {
      if (p.cancel) {
        if (!match.cancelled) { match.cancelled = true; cancelled++; } else skipped++;
        continue;
      }
      let changed = false;
      if (match.cancelled) { match.cancelled = false; changed = true; } // re-RSVP after cancelling
      if (!match.email && p.email) { match.email = p.email; changed = true; }
      if (!match.phone && p.phone) { match.phone = p.phone; changed = true; }
      if (match.role === 'other' && p.role !== 'other') { match.role = p.role; changed = true; }
      if (match.name.split(' ').length < p.name.split(' ').length) { match.name = p.name; changed = true; }
      if (changed) { updated++; reindex(match); } else skipped++;
      continue;
    }
    if (p.cancel) { skipped++; continue; } // cancelling someone we never had
    const a: Attendee = {
      id: uid(),
      name: p.name || p.email.split('@')[0] || 'Unknown',
      email: p.email,
      phone: p.phone,
      role: p.role,
      rsvpAt: p.rsvpAt ?? new Date().toISOString(),
      order: order++,
      cancelled: false,
      checkedInAt: null,
      walkIn: false,
      note: '',
      messagedStatus: null,
    };
    list.push(a);
    reindex(a);
    added++;
  }
  return { attendees: list, added, updated, cancelled, skipped };
}

export type PreviewKind = 'new' | 'update' | 'cancel' | 'duplicate' | 'ignored';

/** Dry-run each parsed row in sequence so the preview matches exactly what import will do. */
export function previewImport(existing: Attendee[], parsed: ParsedRsvp[]): PreviewKind[] {
  let cur = existing;
  return parsed.map((p) => {
    const r = mergeRsvps(cur, [p]);
    cur = r.attendees;
    if (r.added) return 'new';
    if (r.cancelled) return 'cancel';
    if (r.updated) return 'update';
    return p.cancel ? 'ignored' : 'duplicate';
  });
}
