import type { EventSettings, RosterRow } from './types';

export function messageFor(r: RosterRow, s: EventSettings): string {
  const first = r.name.split(' ')[0] || 'there';
  if (r.status === 'confirmed') {
    return `Hi ${first}! Your seat at ${s.name} is confirmed ☕\n📅 ${s.date}\n📍 ${s.venue}\nBring your laptop + charger and an idea you want to ship. If you can't make it, just reply "cancel" so we can pass your seat on.`;
  }
  if (r.status === 'waitlist') {
    return `Hi ${first}! Thanks for your RSVP to ${s.name}. We're full right now, so you're #${r.waitlistPos} on the waitlist. We'll message you the moment a seat opens up.`;
  }
  return `Hi ${first}, we've marked you as not attending ${s.name}. If plans change, reply and we'll check for an open seat.`;
}

export function whatsappLink(phone: string, text: string): string | null {
  if (!phone) return null;
  return `https://wa.me/91${phone}?text=${encodeURIComponent(text)}`;
}
