import { useCallback, useMemo, useState } from 'react';
import type { AppState, Attendee, EventSettings, ParsedRsvp, Role } from './types';
import { DEFAULT_STATE, usePersistentState } from './store';
import { buildRoster, mergeRsvps, uid } from './roster';
import { makeTeams } from './teams';
import { parseRsvps } from './parse';
import { rosterToCsv, download } from './csv';
import { SAMPLE_CHAT } from './sample';
import { Toast, type ToastMsg } from './ui';
import { Tonight } from './components/Tonight';
import { Import } from './components/Import';
import { Roster } from './components/Roster';
import { Door } from './components/Door';
import { Teams } from './components/Teams';
import { Settings } from './components/Settings';
import { Welcome } from './components/Welcome';

type Tab = 'tonight' | 'import' | 'roster' | 'door' | 'teams' | 'settings';

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: 'tonight', label: 'Tonight', icon: '☕' },
  { id: 'import', label: 'Import', icon: '⇩' },
  { id: 'roster', label: 'Roster', icon: '☰' },
  { id: 'door', label: 'Door', icon: '🚪' },
  { id: 'teams', label: 'Teams', icon: '◎' },
  { id: 'settings', label: 'Settings', icon: '⚙' },
];

const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'event';

export default function App() {
  const [state, setState] = usePersistentState();
  const [tab, setTab] = useState<Tab>('tonight');
  const [toast, setToast] = useState<ToastMsg | null>(null);
  const rows = useMemo(() => buildRoster(state.attendees, state.settings), [state.attendees, state.settings]);

  const notify = useCallback((text: string, undo?: () => void) => setToast({ id: Date.now(), text, undo }), []);
  const clearToast = useCallback(() => setToast(null), []);

  /** Apply a change and offer Undo that restores the exact previous state. */
  const change = (fn: (s: AppState) => AppState, msg?: string) => {
    const prev = state;
    setState(fn(state));
    if (msg) notify(msg, () => setState(prev));
  };

  const patchAttendee = (id: string, patch: Partial<Attendee>, msg?: string) =>
    change((s) => ({ ...s, attendees: s.attendees.map((a) => (a.id === id ? { ...a, ...patch } : a)) }), msg);

  const setSettings = (p: Partial<EventSettings>) => setState((s) => ({ ...s, settings: { ...s.settings, ...p } }));

  const importRsvps = (parsed: ParsedRsvp[]) => {
    const r = mergeRsvps(state.attendees, parsed);
    const bits = [r.added && `${r.added} added`, r.updated && `${r.updated} updated`, r.cancelled && `${r.cancelled} cancelled`].filter(Boolean);
    change((s) => ({ ...s, attendees: r.attendees }), bits.length ? `Imported: ${bits.join(', ')}` : 'Nothing new in that import');
    setTab('roster');
  };

  const loadSample = () => {
    const r = mergeRsvps([], parseRsvps(SAMPLE_CHAT));
    change((s) => ({ ...s, attendees: r.attendees, teams: [], seenWelcome: true }), `Loaded ${r.added} sample RSVPs — clear them in Settings`);
    setTab('roster');
  };

  const nextOrder = () => state.attendees.reduce((m, a) => Math.max(m, a.order), -1) + 1;
  const newAttendee = (p: { name: string; email?: string; phone?: string; role: Role }, extra: Partial<Attendee> = {}): Attendee => ({
    id: uid(), name: p.name, email: p.email ?? '', phone: p.phone ?? '', role: p.role, messagedStatus: null,
    rsvpAt: new Date().toISOString(), order: nextOrder(), cancelled: false, checkedInAt: null, walkIn: false, note: '', ...extra,
  });

  const teamOf = (id: string) => { const i = state.teams.findIndex((t) => t.includes(id)); return i < 0 ? null : i; };
  const stamp = new Date().toISOString().slice(0, 10);

  return (
    <div className="app">
      <header className="topbar">
        <button className="brand" onClick={() => setTab('tonight')} aria-label="Home">
          <span className="brand-mark">☕</span>
          <span className="brand-text">Chai <em>Check-in</em></span>
        </button>
        <nav className="tabs" aria-label="Sections">
          {TABS.map((t) => (
            <button key={t.id} className={`tab ${tab === t.id ? 'on' : ''}`} onClick={() => setTab(t.id)} aria-current={tab === t.id ? 'page' : undefined}>
              <span className="tab-icon" aria-hidden="true">{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </nav>
      </header>

      <main>
        {tab === 'tonight' && <Tonight state={state} rows={rows} go={setTab} loadSample={loadSample} />}
        {tab === 'import' && <Import attendees={state.attendees} settings={state.settings} onImport={importRsvps} openSettings={() => setTab('settings')} />}
        {tab === 'roster' && (
          <Roster
            rows={rows} settings={state.settings} notify={notify}
            update={patchAttendee}
            remove={(id) => { const a = state.attendees.find((x) => x.id === id); change((s) => ({ ...s, attendees: s.attendees.filter((x) => x.id !== id), teams: s.teams.map((t) => t.filter((x) => x !== id)) }), `Deleted ${a?.name ?? 'person'}`); }}
            addPerson={(p) => change((s) => ({ ...s, attendees: [...s.attendees, newAttendee(p)] }), `${p.name} added to the queue`)}
            markMessaged={(ids) => setState((s) => ({ ...s, attendees: s.attendees.map((a) => { const r = rows.find((x) => x.id === a.id); return ids.includes(a.id) && r ? { ...a, messagedStatus: r.status } : a; }) }))}
            exportCsv={() => download(`${slug(state.settings.name)}-roster-${stamp}.csv`, rosterToCsv(rows, teamOf))}
          />
        )}
        {tab === 'door' && (
          <Door
            rows={rows} settings={state.settings}
            checkIn={(id) => { const a = state.attendees.find((x) => x.id === id); patchAttendee(id, { checkedInAt: new Date().toISOString(), cancelled: false }, `${a?.name} checked in ☕`); }}
            undoCheckIn={(id) => { const a = state.attendees.find((x) => x.id === id); patchAttendee(id, { checkedInAt: null }, `${a?.name} un-checked`); }}
            walkIn={(name, role) => change((s) => ({ ...s, attendees: [...s.attendees, newAttendee({ name, role }, { walkIn: true, checkedInAt: new Date().toISOString() })] }), `${name} let in as a walk-in`)}
          />
        )}
        {tab === 'teams' && (
          <Teams
            rows={rows} teams={state.teams} teamSize={state.settings.teamSize} notify={notify}
            setTeamSize={(n) => setSettings({ teamSize: n })}
            form={(source, seed) => {
              const pool = rows.filter((r) => (source === 'here' ? r.checkedInAt && r.status !== 'cancelled' : r.status === 'confirmed'));
              change((s) => ({ ...s, teams: makeTeams(pool, s.settings.teamSize, seed) }), s0(state.teams.length) );
            }}
            move={(id, to) => setState((s) => ({ ...s, teams: s.teams.map((t, i) => (i === to ? [...t.filter((x) => x !== id), id] : t.filter((x) => x !== id))).filter((t, i) => t.length || i === to) }))}
            clear={() => change((s) => ({ ...s, teams: [] }), 'Teams cleared')}
          />
        )}
        {tab === 'settings' && (
          <Settings
            state={state} setSettings={setSettings}
            restore={(d) => change(() => ({ ...DEFAULT_STATE, ...d, settings: { ...DEFAULT_STATE.settings, ...d.settings } }), `Restored ${d.attendees.length} people from backup`)}
            reset={() => change((s) => ({ ...DEFAULT_STATE, settings: s.settings, seenWelcome: true }), 'All RSVPs cleared')}
            showWelcome={() => setState((s) => ({ ...s, seenWelcome: false }))}
            exportJson={() => download(`${slug(state.settings.name)}-backup-${stamp}.json`, JSON.stringify(state, null, 2), 'application/json')}
          />
        )}
      </main>

      <footer className="foot">Data stays in this browser · <button className="link-btn" onClick={() => setTab('settings')}>Back up</button></footer>

      {!state.seenWelcome && <Welcome onClose={() => setState((s) => ({ ...s, seenWelcome: true }))} onSample={loadSample} />}
      <Toast toast={toast} onDone={clearToast} />
    </div>
  );
}

const s0 = (had: number) => (had ? 'Teams reshuffled' : 'Teams formed');
