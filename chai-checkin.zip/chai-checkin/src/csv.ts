import type { RosterRow } from './types';

const esc = (v: string) => (/[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);

export function rosterToCsv(rows: RosterRow[], teamOf: (id: string) => number | null): string {
  const header = ['Name', 'Email', 'Phone', 'Role', 'Status', 'Waitlist #', 'Late RSVP', 'RSVP time', 'Checked in', 'Walk-in', 'Team', 'Note'];
  const lines = rows.map((r) => [
    r.name, r.email, r.phone, r.role, r.status,
    r.waitlistPos ? String(r.waitlistPos) : '',
    r.late ? 'yes' : '', new Date(r.rsvpAt).toLocaleString(),
    r.checkedInAt ? new Date(r.checkedInAt).toLocaleTimeString() : '',
    r.walkIn ? 'yes' : '',
    teamOf(r.id) !== null ? `Team ${teamOf(r.id)! + 1}` : '', r.note,
  ].map(esc).join(','));
  return [header.join(','), ...lines].join('\n');
}

export function download(filename: string, content: string, type = 'text/csv') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
