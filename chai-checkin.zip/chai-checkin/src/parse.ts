import type { ParsedRsvp, Role } from './types';

const EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/;
// Indian mobile numbers with optional +91 / 0 prefix and spaces/dashes.
const PHONE_RE = /(?:\+?91[\s-]?|0)?[6-9]\d{4}[\s-]?\d{5}\b/;
// WhatsApp exports: "[24/10/26, 5:30 PM] Name: msg" (iOS) or "24/10/2026, 17:30 - Name: msg" (Android)
const WA_IOS = /^‎?\[(\d{1,2})\/(\d{1,2})\/(\d{2,4}),\s*(\d{1,2}):(\d{2})(?::\d{2})?\s*([AaPp][Mm])?\]\s*([^:]+):\s*(.*)$/;
const WA_ANDROID = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4}),\s*(\d{1,2}):(\d{2})\s*([AaPp][Mm])?\s*-\s*([^:]+):\s*(.*)$/;

const CANCEL_RE = /\b(cancel(?:led|ling)?|can'?t (?:make|come|attend)|cannot (?:make|come|attend)|won'?t (?:make|be able)|drop(?:ping)? out|not coming|withdraw)\b/i;
const RSVP_RE = /\b(rsvp|count me in|i'?m in|in for|register|join|attend(?:ing)?|coming|interested|yes|seat)\b/i;

const ROLE_WORDS: [Role, RegExp][] = [
  ['ai/ml', /\b(ai|ml|machine learning|data scien\w*|llm|genai)\b/i],
  ['fullstack', /\b(full[\s-]?stack)\b/i],
  ['frontend', /\b(front[\s-]?end|react|ui dev|next\.?js|vue|angular)\b/i],
  ['backend', /\b(back[\s-]?end|api|node|django|fastapi|java|spring|go(?:lang)?)\b/i],
  ['design', /\b(design(?:er)?|ui\/ux|ux|figma|product design)\b/i],
];

export function detectRole(text: string): Role {
  for (const [role, re] of ROLE_WORDS) if (re.test(text)) return role;
  return 'other';
}

export function normalizePhone(raw: string): string {
  const digits = raw.replace(/\D/g, '');
  return digits.length >= 10 ? digits.slice(-10) : '';
}

function toIso(d: string, m: string, y: string, h: string, min: string, ampm?: string): string | null {
  let year = Number(y);
  if (year < 100) year += 2000;
  let hour = Number(h);
  if (ampm) {
    const pm = ampm.toLowerCase() === 'pm';
    if (pm && hour < 12) hour += 12;
    if (!pm && hour === 12) hour = 0;
  }
  const date = new Date(year, Number(m) - 1, Number(d), hour, Number(min));
  return isNaN(date.getTime()) ? null : date.toISOString();
}

function titleCase(s: string): string {
  return s
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join(' ');
}

/** Pull a human name out of free text once email/phone/role words are removed. */
function guessName(text: string): string {
  let t = text
    .replace(EMAIL_RE, ' ')
    .replace(PHONE_RE, ' ')
    .replace(/\b(hi|hey|hello|name|is|i am|i'm|this is|my|here|pls|please|rsvp|count me in|for the event|thanks|thank you|email|phone|role|engineer|developer|dev|student|here|also|and|the|a|for|me|in|im|am|i|count|interested|coming|attending|sorry|guys|cancel|seat|number|mail|at|with|plus)\b/gi, ' ')
    .replace(/[-–—|,:;()[\]<>"'!?.]+/g, ' ');
  for (const [, re] of ROLE_WORDS) t = t.replace(re, ' ');
  const words = t.split(/\s+/).filter((w) => /^[A-Za-z][A-Za-z.]*$/.test(w));
  return titleCase(words.slice(0, 3).join(' '));
}

function splitCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = '';
  let q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (q) {
      if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (c === '"') q = false;
      else cur += c;
    } else if (c === '"') q = true;
    else if (c === ',') { out.push(cur.trim()); cur = ''; }
    else cur += c;
  }
  out.push(cur.trim());
  return out;
}

function parseCsv(lines: string[]): ParsedRsvp[] {
  const header = splitCsvLine(lines[0]).map((h) => h.toLowerCase());
  const col = (...keys: string[]) => header.findIndex((h) => keys.some((k) => h.includes(k)));
  const iName = col('name');
  const iEmail = col('email', 'mail');
  const iPhone = col('phone', 'mobile', 'whatsapp', 'number');
  const iRole = col('role', 'skill', 'stack', 'track');
  const iTime = col('timestamp', 'time', 'date', 'submitted');
  const iStatus = col('status', 'attending', 'coming');

  return lines.slice(1).map((line) => {
    const c = splitCsvLine(line);
    const get = (i: number) => (i >= 0 ? c[i] ?? '' : '');
    const t = get(iTime);
    const parsedTime = t ? new Date(t) : null;
    const status = get(iStatus);
    return {
      name: titleCase(get(iName)) || guessName(line),
      email: (get(iEmail).match(EMAIL_RE)?.[0] ?? line.match(EMAIL_RE)?.[0] ?? '').toLowerCase(),
      phone: normalizePhone(get(iPhone) || (line.match(PHONE_RE)?.[0] ?? '')),
      role: detectRole(get(iRole) || line),
      rsvpAt: parsedTime && !isNaN(parsedTime.getTime()) ? parsedTime.toISOString() : null,
      cancel: /^(no|cancel)/i.test(status),
    };
  }).filter((r) => r.name || r.email || r.phone);
}

/**
 * Parse pasted RSVPs: a CSV export (Google Forms, Sheets), a WhatsApp chat export,
 * or one-person-per-line free text. Pure function — no network.
 */
export function parseRsvps(input: string): ParsedRsvp[] {
  const lines = input.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return [];

  const first = lines[0].toLowerCase();
  if (first.includes(',') && /(name|email)/.test(first) && !WA_IOS.test(lines[0]) && !WA_ANDROID.test(lines[0])) {
    return parseCsv(lines);
  }

  const out: ParsedRsvp[] = [];
  for (const line of lines) {
    const wa = line.match(WA_IOS) || line.match(WA_ANDROID);
    if (wa) {
      const [, d, m, y, h, min, ampm, sender, msg] = wa;
      const cancel = CANCEL_RE.test(msg);
      const hasContact = EMAIL_RE.test(msg) || PHONE_RE.test(msg);
      if (!cancel && !RSVP_RE.test(msg) && !hasContact) continue; // chatter, skip
      const senderIsNumber = /^[+\d\s-]+$/.test(sender.trim());
      out.push({
        name: senderIsNumber ? guessName(msg) : titleCase(sender.replace(/[~ ‎]/g, '').trim()),
        email: (msg.match(EMAIL_RE)?.[0] ?? '').toLowerCase(),
        phone: normalizePhone(msg.match(PHONE_RE)?.[0] ?? (senderIsNumber ? sender : '')),
        role: detectRole(msg),
        rsvpAt: toIso(d, m, y, h, min, ampm),
        cancel,
      });
      continue;
    }
    const cancel = CANCEL_RE.test(line);
    const name = guessName(line);
    const email = (line.match(EMAIL_RE)?.[0] ?? '').toLowerCase();
    const phone = normalizePhone(line.match(PHONE_RE)?.[0] ?? '');
    if (!name && !email && !phone) continue;
    out.push({ name, email, phone, role: detectRole(line), rsvpAt: null, cancel });
  }
  return out;
}

/** Stable identity used for de-duplication: email, then phone, then name. */
export function identityKeys(p: { name: string; email: string; phone: string }): string[] {
  const keys: string[] = [];
  if (p.email) keys.push('e:' + p.email.toLowerCase());
  if (p.phone) keys.push('p:' + p.phone);
  if (p.name) keys.push('n:' + p.name.toLowerCase().replace(/\s+/g, ' '));
  return keys;
}
