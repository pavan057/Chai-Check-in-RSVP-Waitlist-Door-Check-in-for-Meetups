import { useState } from 'react';
import type { Role, RosterRow } from '../types';
import { ROLE_LABEL, RoleChip, copyText } from '../ui';

export const TEAM_NAMES = ['Masala', 'Elaichi', 'Adrak', 'Irani', 'Sulaimani', 'Kulhad', 'Cutting', 'Kesar', 'Pudina', 'Gud', 'Zafrani', 'Dalchini', 'Tulsi', 'Kadak', 'Malai', 'Noon'];
export const teamName = (i: number) => `Team ${TEAM_NAMES[i % TEAM_NAMES.length]}${i >= TEAM_NAMES.length ? ` ${Math.floor(i / TEAM_NAMES.length) + 1}` : ''}`;

export function Teams({ rows, teams, teamSize, setTeamSize, form, move, clear, notify }: {
  rows: RosterRow[]; teams: string[][]; teamSize: number; setTeamSize: (n: number) => void;
  form: (source: 'here' | 'seated', seed: number) => void; move: (id: string, to: number) => void;
  clear: () => void; notify: (t: string) => void;
}) {
  const here = rows.filter((r) => r.checkedInAt && r.status !== 'cancelled');
  const seated = rows.filter((r) => r.status === 'confirmed');
  const [source, setSource] = useState<'here' | 'seated'>(here.length ? 'here' : 'seated');
  const pool = source === 'here' ? here : seated;
  const byId = new Map(rows.map((r) => [r.id, r]));
  const assigned = new Set(teams.flat());
  const unassigned = here.filter((r) => !assigned.has(r.id));

  const announce = async () => {
    const text = teams.map((t, i) => `${teamName(i)}: ${t.map((id) => byId.get(id)?.name).filter(Boolean).join(', ')}`).join('\n');
    if (await copyText(text)) notify('Team list copied — paste it in the group');
  };

  return (
    <section className="view">
      <header className="view-head">
        <h1>Teams</h1>
        <p>Balanced teams with a mix of roles, so no team ends up with four designers and no backend.</p>
      </header>

      <div className="card team-controls">
        <label>From
          <select value={source} onChange={(e) => setSource(e.target.value as 'here' | 'seated')}>
            <option value="here">People checked in ({here.length})</option>
            <option value="seated">Everyone seated ({seated.length})</option>
          </select>
        </label>
        <label>Team size
          <div className="stepper">
            <button type="button" onClick={() => setTeamSize(Math.max(2, teamSize - 1))} aria-label="Smaller teams">−</button>
            <b>{teamSize}</b>
            <button type="button" onClick={() => setTeamSize(Math.min(8, teamSize + 1))} aria-label="Bigger teams">+</button>
          </div>
        </label>
        <span className="small muted">≈ {Math.max(1, Math.round(pool.length / teamSize))} teams</span>
        <span className="spacer" />
        <button className="btn primary" disabled={pool.length < 2} onClick={() => form(source, Date.now())}>{teams.length ? 'Shuffle teams' : 'Form teams'}</button>
        {teams.length > 0 && <button className="btn" onClick={announce}>Copy for group chat</button>}
        {teams.length > 0 && <button className="btn ghost" onClick={clear}>Clear</button>}
      </div>

      {unassigned.length > 0 && teams.length > 0 && (
        <div className="card warn-card">
          <b>{unassigned.length} arrived after teams were made:</b>{' '}
          {unassigned.map((r) => (
            <span key={r.id} className="late-join">
              {r.name}
              <select value="" onChange={(e) => move(r.id, Number(e.target.value))} aria-label={`Add ${r.name} to a team`}>
                <option value="" disabled>Add to…</option>
                {teams.map((t, i) => <option key={i} value={i}>{teamName(i)} ({t.length})</option>)}
              </select>
            </span>
          ))}
        </div>
      )}

      {teams.length === 0 ? (
        <div className="empty card">
          <h2>No teams yet</h2>
          <p>{pool.length < 2 ? 'You need at least two people. Check people in at the door, or switch to "Everyone seated".' : `Ready to split ${pool.length} people into teams of about ${teamSize}.`}</p>
        </div>
      ) : (
        <div className="teams">
          {teams.map((t, i) => {
            const mix = t.reduce<Record<string, number>>((m, id) => { const r = byId.get(id); if (r) m[r.role] = (m[r.role] ?? 0) + 1; return m; }, {});
            return (
              <div key={i} className="team card">
                <div className="team-head"><h3>{teamName(i)}</h3><span className="small muted">{t.length} people</span></div>
                <div className="mix">{Object.entries(mix).map(([k, v]) => <span key={k} className="small">{v}× {ROLE_LABEL[k as Role]}</span>)}</div>
                <ul>
                  {t.map((id) => {
                    const r = byId.get(id); if (!r) return null;
                    return (
                      <li key={id}>
                        <span>{r.name}</span>
                        <RoleChip role={r.role} />
                        <select className="move" value={i} onChange={(e) => move(id, Number(e.target.value))} aria-label={`Move ${r.name}`}>
                          {teams.map((_, j) => <option key={j} value={j}>{j === i ? 'Move…' : `→ ${teamName(j)}`}</option>)}
                        </select>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
