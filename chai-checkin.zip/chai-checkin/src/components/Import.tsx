import { useMemo, useRef, useState } from 'react';
import type { Attendee, EventSettings, ParsedRsvp } from '../types';
import { parseRsvps } from '../parse';
import { previewImport, type PreviewKind } from '../roster';
import { parseWithGemini } from '../gemini';
import { RoleChip } from '../ui';
import { SAMPLE_CHAT } from '../sample';

const KIND_LABEL: Record<PreviewKind, string> = {
  new: 'New', update: 'Updates info', cancel: 'Cancels', duplicate: 'Already in list', ignored: 'Not in list',
};

export function Import({ attendees, settings, onImport, openSettings }: {
  attendees: Attendee[]; settings: EventSettings;
  onImport: (p: ParsedRsvp[]) => void; openSettings: () => void;
}) {
  const [text, setText] = useState('');
  const [parsed, setParsed] = useState<ParsedRsvp[] | null>(null);
  const [skip, setSkip] = useState<Set<number>>(new Set());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [drag, setDrag] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const kinds = useMemo(() => (parsed ? previewImport(attendees, parsed) : []), [parsed, attendees]);
  const selected = parsed?.filter((_, i) => !skip.has(i)) ?? [];
  const counts = kinds.reduce<Record<string, number>>((m, k, i) => (skip.has(i) ? m : { ...m, [k]: (m[k] ?? 0) + 1 }), {});
  const actionable = (counts.new ?? 0) + (counts.update ?? 0) + (counts.cancel ?? 0);

  const readFile = async (f: File) => {
    if (f.size > 2_000_000) { setError('That file is over 2 MB. Export just the RSVP messages or rows.'); return; }
    setText(await f.text()); setParsed(null); setError('');
  };

  const runOffline = () => {
    setError('');
    const r = parseRsvps(text);
    if (!r.length) { setError("Couldn't find any RSVPs. Each person needs a name, email or phone number. Try the Gemini parser for very messy text."); return; }
    setParsed(r); setSkip(new Set());
  };

  const runGemini = async () => {
    if (!settings.geminiKey) { openSettings(); return; }
    setBusy(true); setError('');
    try {
      const r = await parseWithGemini(text, settings.geminiKey, settings.geminiModel);
      if (!r.length) setError('Gemini found no RSVPs in that text.');
      else { setParsed(r); setSkip(new Set()); }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Gemini request failed.');
    } finally { setBusy(false); }
  };

  const commit = () => {
    onImport(selected);
    setText(''); setParsed(null); setSkip(new Set());
  };

  return (
    <section className="view">
      <header className="view-head">
        <h1>Import RSVPs</h1>
        <p>Paste anything people sent you. Nothing changes until you confirm the preview.</p>
      </header>

      {!parsed ? (
        <div className="card">
          <div
            className={`dropzone ${drag ? 'drag' : ''}`}
            onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) readFile(f); }}
          >
            <textarea
              value={text}
              onChange={(e) => { setText(e.target.value); setError(''); }}
              placeholder={'Paste here, or drop a .txt / .csv file.\n\n[12/10/26, 9:02 AM] Ananya Rao: Count me in! ananya@example.com, frontend\nPriya Sharma, priya@example.com, +91 98765 43210, designer\nTimestamp,Name,Email,Phone,Role  ← Google Form CSV works too'}
              rows={12}
              aria-label="RSVP text"
            />
          </div>
          <div className="formats">
            <span>✓ WhatsApp chat export</span><span>✓ Google Forms / Sheets CSV</span><span>✓ One person per line</span><span>✓ "cancel" messages free up seats</span>
          </div>
          {error && <p className="error" role="alert">{error}</p>}
          <div className="btn-row">
            <button className="btn primary" disabled={!text.trim()} onClick={runOffline}>Preview import</button>
            <button className="btn" disabled={!text.trim() || busy} onClick={runGemini} title="For messy DMs the offline parser can't read">
              {busy ? <><span className="spinner" /> Reading with Gemini…</> : settings.geminiKey ? '✨ Preview with Gemini' : '✨ Set up Gemini'}
            </button>
            <span className="spacer" />
            <input ref={fileRef} type="file" accept=".txt,.csv,text/plain,text/csv" hidden onChange={(e) => e.target.files?.[0] && readFile(e.target.files[0])} />
            <button className="btn ghost" onClick={() => fileRef.current?.click()}>Choose file</button>
            {!text && <button className="btn ghost" onClick={() => setText(SAMPLE_CHAT)}>Paste sample</button>}
          </div>
        </div>
      ) : (
        <div className="card">
          <div className="card-head">
            <h2>Preview · {parsed.length} found</h2>
            <div className="chip-row">
              {(['new', 'update', 'cancel', 'duplicate', 'ignored'] as PreviewKind[]).filter((k) => counts[k]).map((k) => (
                <span key={k} className={`chip kind-${k}`}>{counts[k]} {KIND_LABEL[k].toLowerCase()}</span>
              ))}
            </div>
          </div>
          <p className="hint">Untick anyone who shouldn't be imported (like yourself or a co-organizer).</p>
          <div className="table-wrap">
            <table className="table">
              <thead><tr><th></th><th>Name</th><th>Contact</th><th>Role</th><th>Sent</th><th>Result</th></tr></thead>
              <tbody>
                {parsed.map((p, i) => (
                  <tr key={i} className={skip.has(i) ? 'skipped' : ''}>
                    <td><input type="checkbox" checked={!skip.has(i)} aria-label={`Include ${p.name}`} onChange={() => {
                      const n = new Set(skip); if (n.has(i)) n.delete(i); else n.add(i); setSkip(n);
                    }} /></td>
                    <td><b>{p.name || <i className="muted">No name</i>}</b></td>
                    <td className="mono small">{[p.email, p.phone].filter(Boolean).join(' · ') || <i className="muted">—</i>}</td>
                    <td><RoleChip role={p.role} /></td>
                    <td className="small muted">{p.rsvpAt ? new Date(p.rsvpAt).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : 'now'}</td>
                    <td><span className={`chip kind-${kinds[i]}`}>{KIND_LABEL[kinds[i]]}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="btn-row">
            <button className="btn primary" disabled={!actionable} onClick={commit}>
              {actionable ? `Apply ${actionable} change${actionable > 1 ? 's' : ''}` : 'Nothing new to add'}
            </button>
            <button className="btn ghost" onClick={() => setParsed(null)}>Back to edit</button>
          </div>
        </div>
      )}
    </section>
  );
}
