import { useRef, useState } from 'react';
import type { AppState, EventSettings } from '../types';

export function Settings({ state, setSettings, restore, reset, showWelcome, exportJson }: {
  state: AppState; setSettings: (p: Partial<EventSettings>) => void;
  restore: (s: AppState) => void; reset: () => void; showWelcome: () => void; exportJson: () => void;
}) {
  const s = state.settings;
  const [showKey, setShowKey] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [err, setErr] = useState('');
  const file = useRef<HTMLInputElement>(null);

  return (
    <section className="view">
      <header className="view-head"><h1>Settings</h1><p>Changes save automatically on this device.</p></header>

      <div className="card form-grid">
        <h2>Event</h2>
        <label>Event name<input value={s.name} onChange={(e) => setSettings({ name: e.target.value })} /></label>
        <label>Date &amp; time (as shown in messages)<input value={s.date} onChange={(e) => setSettings({ date: e.target.value })} /></label>
        <label className="wide">Venue<input value={s.venue} onChange={(e) => setSettings({ venue: e.target.value })} /></label>
        <label>Seats<input type="number" min={1} max={2000} value={s.capacity} onChange={(e) => setSettings({ capacity: Math.max(1, Number(e.target.value) || 1) })} /></label>
        <label>RSVP deadline<input type="datetime-local" value={s.deadline} onChange={(e) => setSettings({ deadline: e.target.value })} /></label>
        <p className="hint wide">RSVPs sent after the deadline are kept, but queued behind everyone who made it.</p>
      </div>

      <div className="card form-grid">
        <h2>✨ Gemini (optional)</h2>
        <p className="hint wide">Only needed for very messy text the offline parser can't read. Get a free key at <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">aistudio.google.com/apikey</a>. The key stays in this browser and is sent only to Google.</p>
        <label className="wide">API key
          <div className="inline">
            <input type={showKey ? 'text' : 'password'} value={s.geminiKey} placeholder="AIza…" autoComplete="off" onChange={(e) => setSettings({ geminiKey: e.target.value.trim() })} />
            <button className="btn small ghost" type="button" onClick={() => setShowKey((v) => !v)}>{showKey ? 'Hide' : 'Show'}</button>
          </div>
        </label>
        <label>Model<input value={s.geminiModel} onChange={(e) => setSettings({ geminiModel: e.target.value.trim() })} /></label>
      </div>

      <div className="card">
        <h2>Your data</h2>
        <p className="hint">Everything lives in this browser. Download a backup before switching laptops, or to hand the door over to a co-organizer.</p>
        <div className="btn-row">
          <button className="btn" onClick={exportJson}>Download backup</button>
          <input ref={file} type="file" accept="application/json,.json" hidden onChange={async (e) => {
            const f = e.target.files?.[0]; if (!f) return;
            try {
              const data = JSON.parse(await f.text()) as AppState;
              if (!Array.isArray(data.attendees) || !data.settings) throw new Error();
              restore(data); setErr('');
            } catch { setErr("That file isn't a Chai Check-in backup."); }
            e.target.value = '';
          }} />
          <button className="btn" onClick={() => file.current?.click()}>Restore backup</button>
          <button className="btn ghost" onClick={showWelcome}>Show welcome tour</button>
          <span className="spacer" />
          {confirmReset
            ? <><span className="small">Delete every RSVP?</span><button className="btn small danger-solid" onClick={() => { reset(); setConfirmReset(false); }}>Yes, clear all</button><button className="btn small ghost" onClick={() => setConfirmReset(false)}>Keep</button></>
            : <button className="btn ghost danger" onClick={() => setConfirmReset(true)}>Clear all data</button>}
        </div>
        {err && <p className="error">{err}</p>}
      </div>
    </section>
  );
}
