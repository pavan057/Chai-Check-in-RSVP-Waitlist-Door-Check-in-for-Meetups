import { useEffect, useMemo, useRef, useState } from 'react';
import type { Role, RosterRow, EventSettings } from '../types';
import { ROLES } from '../types';
import { Avatar, ROLE_LABEL, RoleChip, StatusChip } from '../ui';

export function Door({ rows, settings, checkIn, undoCheckIn, walkIn }: {
  rows: RosterRow[]; settings: EventSettings;
  checkIn: (id: string) => void; undoCheckIn: (id: string) => void;
  walkIn: (name: string, role: Role) => void;
}) {
  const [q, setQ] = useState('');
  const [confirmWait, setConfirmWait] = useState<RosterRow | null>(null);
  const [walkRole, setWalkRole] = useState<Role>('other');
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => { input.current?.focus(); }, []);

  const active = rows.filter((r) => r.status !== 'cancelled');
  const here = active.filter((r) => r.checkedInAt);
  const seated = active.filter((r) => r.status === 'confirmed');
  const openSeats = Math.max(0, settings.capacity - here.length);
  const pct = Math.min(100, Math.round((here.length / Math.max(1, settings.capacity)) * 100));

  const results = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return [];
    const digits = t.replace(/\D/g, '');
    return rows
      .filter((r) => r.name.toLowerCase().split(' ').some((w) => w.startsWith(t)) || r.name.toLowerCase().includes(t) || r.email.startsWith(t) || (digits.length >= 3 && r.phone.includes(digits)))
      .sort((a, b) => Number(a.status === 'cancelled') - Number(b.status === 'cancelled'))
      .slice(0, 8);
  }, [q, rows]);

  const act = (r: RosterRow) => {
    if (r.checkedInAt) { undoCheckIn(r.id); return; }
    if (r.status !== 'confirmed') { setConfirmWait(r); return; }
    checkIn(r.id); setQ(''); input.current?.focus();
  };

  const recent = [...here].sort((a, b) => (b.checkedInAt! > a.checkedInAt! ? 1 : -1)).slice(0, 6);

  return (
    <section className="view door">
      <div className="door-top">
        <div>
          <div className="door-count"><b>{here.length}</b><span>/ {settings.capacity} here</span></div>
          <div className="bar"><span style={{ width: `${pct}%` }} /></div>
          <p className="small muted">{seated.length - seated.filter((r) => r.checkedInAt).length} seated guests still to arrive · {openSeats} seats free in the room</p>
        </div>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); if (results.length === 1) act(results[0]); }}>
        <input
          ref={input} className="door-search" type="search" value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Type a name or last digits of phone…" aria-label="Find guest" autoComplete="off"
        />
      </form>
      {results.length === 1 && !results[0].checkedInAt && <p className="hint">Press Enter to check in {results[0].name}.</p>}

      <ul className="door-results">
        {results.map((r) => (
          <li key={r.id}>
            <button className={`door-row ${r.checkedInAt ? 'in' : ''} ${r.status}`} onClick={() => act(r)}>
              <Avatar name={r.name} />
              <div className="person-info">
                <b>{r.name}</b>
                <span className="small"><RoleChip role={r.role} /> <StatusChip status={r.status} pos={r.waitlistPos} late={r.late} /></span>
                {r.note && <span className="small note-inline">📝 {r.note}</span>}
              </div>
              <span className="door-action">{r.checkedInAt ? '✓ Here · undo' : r.status === 'confirmed' ? 'Check in' : 'Review'}</span>
            </button>
          </li>
        ))}
        {q.trim() && !results.length && (
          <li className="walkin card">
            <p><b>“{q.trim()}”</b> isn't on the list.</p>
            <div className="btn-row">
              <select value={walkRole} onChange={(e) => setWalkRole(e.target.value as Role)} aria-label="Walk-in role">
                {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
              </select>
              <button className="btn primary" disabled={openSeats === 0} onClick={() => { walkIn(q.trim(), walkRole); setQ(''); input.current?.focus(); }}>
                {openSeats ? 'Let in as walk-in' : 'Room is full'}
              </button>
            </div>
          </li>
        )}
      </ul>

      {!q && (
        <div className="card">
          <h2>Just arrived</h2>
          {recent.length ? (
            <ul className="recent">{recent.map((r) => (
              <li key={r.id}><Avatar name={r.name} /><span>{r.name}</span><span className="small muted">{new Date(r.checkedInAt!).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</span></li>
            ))}</ul>
          ) : <p className="muted">No one checked in yet. Start typing a name above — Enter checks in a single match.</p>}
        </div>
      )}

      {confirmWait && (
        <div className="modal-back" onClick={() => setConfirmWait(null)}>
          <div className="modal" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
            <h2>{confirmWait.name} is {confirmWait.status === 'waitlist' ? `waitlisted (#${confirmWait.waitlistPos})` : 'marked cancelled'}</h2>
            <p>{openSeats > 0 ? `There ${openSeats === 1 ? 'is 1 free seat' : `are ${openSeats} free seats`} in the room right now. Letting them in keeps everyone else's seat.` : 'The room is full. Letting them in goes over capacity.'}</p>
            <div className="btn-row">
              <button className="btn primary" onClick={() => { checkIn(confirmWait.id); setConfirmWait(null); setQ(''); input.current?.focus(); }}>Let them in</button>
              <button className="btn ghost" onClick={() => setConfirmWait(null)}>Not now</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
