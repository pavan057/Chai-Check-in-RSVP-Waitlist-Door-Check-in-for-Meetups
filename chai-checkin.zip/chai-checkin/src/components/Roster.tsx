import { useMemo, useState } from 'react';
import type { Attendee, EventSettings, Role, RosterRow } from '../types';
import { ROLES } from '../types';
import { Avatar, ROLE_LABEL, RoleChip, StatusChip, copyText } from '../ui';
import { messageFor, whatsappLink } from '../messages';

type Filter = 'all' | 'todo' | 'confirmed' | 'waitlist' | 'cancelled' | 'late' | 'here';

export function Roster({ rows, settings, update, remove, addPerson, exportCsv, notify, markMessaged }: {
  rows: RosterRow[]; settings: EventSettings;
  update: (id: string, patch: Partial<Attendee>, msg?: string) => void;
  remove: (id: string) => void;
  addPerson: (p: { name: string; email: string; phone: string; role: Role }) => void;
  exportCsv: () => void; notify: (t: string) => void;
  markMessaged: (ids: string[]) => void;
}) {
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [openId, setOpenId] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [draft, setDraft] = useState({ name: '', email: '', phone: '', role: 'other' as Role });

  const counts = useMemo(() => ({
    all: rows.length,
    todo: rows.filter((r) => r.needsMessage).length,
    confirmed: rows.filter((r) => r.status === 'confirmed').length,
    waitlist: rows.filter((r) => r.status === 'waitlist').length,
    cancelled: rows.filter((r) => r.status === 'cancelled').length,
    late: rows.filter((r) => r.late && r.status !== 'cancelled').length,
    here: rows.filter((r) => r.checkedInAt && r.status !== 'cancelled').length,
  }), [rows]);

  const shown = rows.filter((r) => {
    if (filter === 'todo' && !r.needsMessage) return false;
    if (filter === 'late' && !(r.late && r.status !== 'cancelled')) return false;
    if (filter === 'here' && !(r.checkedInAt && r.status !== 'cancelled')) return false;
    if (['confirmed', 'waitlist', 'cancelled'].includes(filter) && r.status !== filter) return false;
    const t = q.trim().toLowerCase();
    return !t || `${r.name} ${r.email} ${r.phone}`.toLowerCase().includes(t);
  });

  const copyAll = async (status: 'confirmed' | 'waitlist') => {
    const list = rows.filter((r) => r.status === status && r.needsMessage);
    const text = list.map((r) => `— ${r.name}${r.phone ? ` (${r.phone})` : ''}\n${messageFor(r, settings)}`).join('\n\n');
    if (await copyText(text)) {
      markMessaged(list.map((r) => r.id));
      notify(`Copied ${list.length} ${status === 'confirmed' ? 'confirmation' : 'waitlist'} message${list.length > 1 ? 's' : ''} — marked as sent`);
    }
  };
  const todoConfirmed = rows.filter((r) => r.needsMessage && r.status === 'confirmed').length;
  const todoWait = rows.filter((r) => r.needsMessage && r.status === 'waitlist').length;

  const FILTERS: [Filter, string][] = [['all', 'All'], ['todo', 'To message'], ['confirmed', 'Seated'], ['waitlist', 'Waitlist'], ['here', 'Here'], ['late', 'Late'], ['cancelled', 'Cancelled']];

  return (
    <section className="view">
      <header className="view-head row">
        <div>
          <h1>Roster</h1>
          <p>Seats go first-come, first-served. Cancel someone and the next person on the waitlist moves up automatically.</p>
        </div>
        <div className="btn-row">
          <button className="btn" onClick={() => setAdding((v) => !v)}>+ Add person</button>
          <button className="btn ghost" onClick={exportCsv} disabled={!rows.length}>Export CSV</button>
        </div>
      </header>

      {adding && (
        <form className="card add-form" onSubmit={(e) => {
          e.preventDefault(); if (!draft.name.trim()) return;
          addPerson({ ...draft, name: draft.name.trim(), email: draft.email.trim().toLowerCase(), phone: draft.phone.replace(/\D/g, '').slice(-10) });
          setDraft({ name: '', email: '', phone: '', role: 'other' }); setAdding(false);
        }}>
          <input autoFocus required placeholder="Name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} />
          <input type="email" placeholder="Email (optional)" value={draft.email} onChange={(e) => setDraft({ ...draft, email: e.target.value })} />
          <input inputMode="tel" placeholder="Phone (optional)" value={draft.phone} onChange={(e) => setDraft({ ...draft, phone: e.target.value })} />
          <select value={draft.role} onChange={(e) => setDraft({ ...draft, role: e.target.value as Role })}>
            {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
          </select>
          <button className="btn primary">Add to queue</button>
        </form>
      )}

      <div className="toolbar">
        <input className="search" type="search" placeholder="Search name, email or phone" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="filters" role="tablist">
          {FILTERS.map(([f, label]) => (
            <button key={f} role="tab" aria-selected={filter === f} className={`filter ${filter === f ? 'on' : ''}`} onClick={() => setFilter(f)}>
              {label} <span>{counts[f]}</span>
            </button>
          ))}
        </div>
      </div>

      {counts.todo > 0 ? (
        <div className="bulk todo-banner">
          <span><b>{counts.todo}</b> {counts.todo === 1 ? 'person hasn\'t' : 'people haven\'t'} heard where they stand.</span>
          {todoConfirmed > 0 && <button className="link-btn" onClick={() => copyAll('confirmed')}>Copy {todoConfirmed} confirmation{todoConfirmed > 1 ? 's' : ''}</button>}
          {todoWait > 0 && <button className="link-btn" onClick={() => copyAll('waitlist')}>Copy {todoWait} waitlist update{todoWait > 1 ? 's' : ''}</button>}
        </div>
      ) : rows.length > 0 && <div className="bulk">✓ Everyone has been told where they stand.</div>}

      <ul className="people">
        {shown.map((r) => {
          const open = openId === r.id;
          const msg = messageFor(r, settings);
          const wa = whatsappLink(r.phone, msg);
          return (
            <li key={r.id} className={`person ${r.status} ${open ? 'open' : ''}`}>
              <button className="person-main" onClick={() => setOpenId(open ? null : r.id)} aria-expanded={open}>
                <Avatar name={r.name} />
                <div className="person-info">
                  <span className="name-line"><b>{r.name}</b>{r.walkIn && <span className="tag">walk-in</span>}{r.checkedInAt && r.status !== 'cancelled' && <span className="tag here">here</span>}{r.needsMessage && <span className="tag todo">{r.messagedStatus ? 'needs update' : 'to message'}</span>}</span>
                  <span className="mono small muted">{[r.email, r.phone].filter(Boolean).join(' · ') || 'no contact'}</span>
                </div>
                <RoleChip role={r.role} />
                <StatusChip status={r.status} pos={r.waitlistPos} late={r.late} />
              </button>
              {open && (
                <div className="person-detail">
                  <div className="msg-preview">{msg}</div>
                  <div className="btn-row">
                    <button className="btn small" onClick={async () => { if (await copyText(msg)) { markMessaged([r.id]); notify(`Message for ${r.name.split(' ')[0]} copied — marked as sent`); } }}>Copy message</button>
                    {wa && r.status !== 'cancelled' && <a className="btn small wa" href={wa} target="_blank" rel="noreferrer" onClick={() => markMessaged([r.id])}>Open in WhatsApp</a>}
                    <select className="small-select" value={r.role} aria-label="Role" onChange={(e) => update(r.id, { role: e.target.value as Role })}>
                      {ROLES.map((x) => <option key={x} value={x}>{ROLE_LABEL[x]}</option>)}
                    </select>
                    <span className="spacer" />
                    {r.status === 'cancelled'
                      ? <button className="btn small ghost" onClick={() => update(r.id, { cancelled: false }, `${r.name} restored to the queue`)}>Restore</button>
                      : <button className="btn small ghost danger" onClick={() => update(r.id, { cancelled: true }, `${r.name} cancelled — seat passed on`)}>Mark cancelled</button>}
                    <button className="btn small ghost danger" onClick={() => remove(r.id)}>Delete</button>
                  </div>
                  <input className="note" placeholder="Private note (dietary, needs a charger, plus-one…)" value={r.note} onChange={(e) => update(r.id, { note: e.target.value })} />
                  <p className="small muted">RSVP sent {new Date(r.rsvpAt).toLocaleString()}{r.late ? ' — after the deadline' : ''}.</p>
                </div>
              )}
            </li>
          );
        })}
        {!shown.length && <li className="empty-row">{rows.length ? 'Nobody matches that search.' : 'No one here yet — import some RSVPs first.'}</li>}
      </ul>
    </section>
  );
}
