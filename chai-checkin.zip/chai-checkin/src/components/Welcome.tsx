import { Cup } from '../ui';

export function Welcome({ onClose, onSample }: { onClose: () => void; onSample: () => void }) {
  return (
    <div className="modal-back">
      <div className="modal welcome" role="dialog" aria-modal="true" aria-labelledby="welcome-title">
        <div className="welcome-cups"><Cup state="held" /><Cup state="here" /><Cup state="held" /></div>
        <h2 id="welcome-title">Welcome to Chai Check-in</h2>
        <p>Run your meetup's guest list without the spreadsheet juggling. Four steps, one per chai round:</p>
        <ol className="welcome-steps">
          <li><b>Import</b> — paste your WhatsApp chat or form export. Duplicates merge, "cancel" messages free seats.</li>
          <li><b>Message</b> — copy ready-made confirmation and waitlist texts, or open them straight in WhatsApp.</li>
          <li><b>Door</b> — type a name, tap to check in. Walk-ins take one tap.</li>
          <li><b>Teams</b> — balanced, mixed-role teams from whoever actually showed up.</li>
        </ol>
        <p className="small muted">Your data stays in this browser. Nothing is uploaded unless you turn on the optional Gemini parser.</p>
        <div className="btn-row">
          <button className="btn primary" onClick={onClose}>Start with my event</button>
          <button className="btn ghost" onClick={() => { onSample(); onClose(); }}>Explore with sample data</button>
        </div>
      </div>
    </div>
  );
}
