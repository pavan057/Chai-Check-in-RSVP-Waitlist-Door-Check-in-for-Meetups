import type { AppState, RosterRow } from '../types';
import { Cup } from '../ui';

type Tab = 'tonight' | 'import' | 'roster' | 'door' | 'teams' | 'settings';

function until(iso: string) {
  const ms = new Date(iso).getTime() - Date.now();
  if (isNaN(ms)) return null;
  if (ms <= 0) return 'closed';
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  return d > 0 ? `${d}d ${h}h left` : `${h}h ${Math.floor((ms % 3600000) / 60000)}m left`;
}

export function Tonight({ state, rows, go, loadSample }: {
  state: AppState; rows: RosterRow[]; go: (t: Tab) => void; loadSample: () => void;
}) {
  const s = state.settings;
  const seated = rows.filter((r) => r.status === 'confirmed');
  const wait = rows.filter((r) => r.status === 'waitlist');
  const here = rows.filter((r) => r.checkedInAt && r.status !== 'cancelled');
  const cancelled = rows.filter((r) => r.status === 'cancelled');
  const late = rows.filter((r) => r.late && r.status !== 'cancelled');
  const todo = rows.filter((r) => r.needsMessage).length;
  const deadline = until(s.deadline);
  const seats = Math.max(s.capacity, seated.length);

  const steps = [
    { done: rows.length > 0, label: 'Import RSVPs', hint: 'Paste a WhatsApp export, Google Form CSV or a plain list.', tab: 'import' as Tab },
    { done: rows.length > 0 && todo === 0, label: 'Message everyone', hint: todo ? `${todo} still to message — confirmations and waitlist updates are pre-written.` : 'Confirm seats and tell the waitlist where they stand.', tab: 'roster' as Tab },
    { done: here.length > 0, label: 'Run the door', hint: 'Search a name, tap to check in. Walk-ins in one tap.', tab: 'door' as Tab },
    { done: state.teams.length > 0, label: 'Form teams', hint: 'Mixed-role teams from whoever actually showed up.', tab: 'teams' as Tab },
  ];

  return (
    <section className="view">
      <div className="signboard">
        <div className="sign-kicker">Tonight at the counter</div>
        <h1 className="sign-title">{s.name}</h1>
        <div className="sign-meta">
          <span>📅 {s.date}</span>
          <span>📍 {s.venue}</span>
          {deadline && <span className={`deadline ${deadline === 'closed' ? 'closed' : ''}`}>RSVPs {deadline === 'closed' ? 'closed' : deadline}</span>}
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="empty card">
          <div className="empty-cups">{Array.from({ length: 5 }, (_, i) => <Cup key={i} state={i === 2 ? 'here' : 'empty'} />)}</div>
          <h2>No RSVPs yet</h2>
          <p>Paste the messages people sent you — WhatsApp chat, form export or a plain list. Chai Check-in removes duplicates, handles cancellations and keeps seats first-come, first-served.</p>
          <div className="btn-row center">
            <button className="btn primary" onClick={() => go('import')}>Import RSVPs</button>
            <button className="btn ghost" onClick={loadSample}>Try with sample RSVPs</button>
          </div>
        </div>
      ) : (
        <>
          <div className="stats">
            <button className="stat" onClick={() => go('roster')}><b>{seated.length}<small>/{s.capacity}</small></b><span>Seated</span></button>
            <button className="stat" onClick={() => go('roster')}><b>{wait.length}</b><span>Waitlist</span></button>
            <button className="stat accent" onClick={() => go('door')}><b>{here.length}</b><span>Checked in</span></button>
            <button className="stat muted" onClick={() => go('roster')}><b>{cancelled.length}</b><span>Cancelled</span></button>
          </div>

          <div className="card">
            <div className="card-head">
              <h2>Seat map</h2>
              <div className="legend">
                <span><Cup state="empty" /> Open</span>
                <span><Cup state="held" /> Held</span>
                <span><Cup state="here" /> Here</span>
              </div>
            </div>
            <div className="seatmap">
              {Array.from({ length: seats }, (_, i) => {
                const r = seated[i];
                const st = !r ? 'empty' : r.checkedInAt ? 'here' : 'held';
                return <Cup key={i} state={st} title={r ? `${r.name}${r.checkedInAt ? ' — here' : ''}` : `Seat ${i + 1} open`} />;
              })}
            </div>
            {seated.length < s.capacity && wait.length === 0 && (
              <p className="hint">{s.capacity - seated.length} seats still open.</p>
            )}
            {late.length > 0 && <p className="hint warn">{late.length} late RSVP{late.length > 1 ? 's' : ''} placed behind everyone who made the deadline.</p>}
          </div>
        </>
      )}

      <div className="card">
        <h2>Your run sheet</h2>
        <ol className="steps">
          {steps.map((st, i) => (
            <li key={st.label} className={st.done ? 'done' : ''}>
              <span className="step-num">{st.done ? '✓' : i + 1}</span>
              <div>
                <b>{st.label}</b>
                <p>{st.hint}</p>
              </div>
              <button className="btn small ghost" onClick={() => go(st.tab)}>Open</button>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
