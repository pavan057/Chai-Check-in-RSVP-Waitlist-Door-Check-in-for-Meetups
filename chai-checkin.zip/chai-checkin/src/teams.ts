import type { Attendee, Role } from './types';

/** Seeded PRNG so "Shuffle" is reproducible within a session. */
function mulberry32(seed: number) {
  return () => {
    seed |= 0; seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Split people into teams of about `size`, spreading roles evenly:
 * people are grouped by role, then dealt out snake-style so every team
 * gets a mix (e.g. not all designers on one team).
 */
export function makeTeams(people: Attendee[], size: number, seed = 1): string[][] {
  if (!people.length) return [];
  const n = Math.max(1, Math.round(people.length / Math.max(2, size)));
  const rand = mulberry32(seed);
  const priority: Role[] = ['design', 'ai/ml', 'frontend', 'backend', 'fullstack', 'other'];
  const byRole = new Map<Role, Attendee[]>();
  for (const p of people) byRole.set(p.role, [...(byRole.get(p.role) ?? []), p]);
  const dealt: Attendee[] = [];
  for (const r of priority) {
    const group = byRole.get(r) ?? [];
    for (let i = group.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1));
      [group[i], group[j]] = [group[j], group[i]];
    }
    dealt.push(...group);
  }
  const teams: string[][] = Array.from({ length: n }, () => []);
  dealt.forEach((p, i) => {
    const round = Math.floor(i / n);
    const idx = round % 2 === 0 ? i % n : n - 1 - (i % n);
    teams[idx].push(p.id);
  });
  return teams;
}
