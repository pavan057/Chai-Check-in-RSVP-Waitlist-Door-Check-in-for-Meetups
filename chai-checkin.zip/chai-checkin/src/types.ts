export type Role = 'frontend' | 'backend' | 'fullstack' | 'design' | 'ai/ml' | 'other';

export const ROLES: Role[] = ['frontend', 'backend', 'fullstack', 'design', 'ai/ml', 'other'];

export interface Attendee {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: Role;
  /** ISO time the RSVP was sent (from WhatsApp/CSV timestamp) or imported. */
  rsvpAt: string;
  /** Position in import order — first come, first served. */
  order: number;
  cancelled: boolean;
  checkedInAt: string | null;
  walkIn: boolean;
  note: string;
  /** Seat status we last messaged them about; if it differs from the current status they need an update. */
  messagedStatus?: SeatStatus | null;
}

export interface EventSettings {
  name: string;
  date: string;
  venue: string;
  capacity: number;
  /** datetime-local string, e.g. 2026-10-21T23:59 */
  deadline: string;
  teamSize: number;
  geminiKey: string;
  geminiModel: string;
}

export type SeatStatus = 'confirmed' | 'waitlist' | 'cancelled';

export interface RosterRow extends Attendee {
  status: SeatStatus;
  late: boolean;
  waitlistPos: number | null;
  needsMessage: boolean;
}

/** What a parser returns before it becomes an Attendee. */
export interface ParsedRsvp {
  name: string;
  email: string;
  phone: string;
  role: Role;
  rsvpAt: string | null;
  cancel: boolean;
}

export interface AppState {
  settings: EventSettings;
  attendees: Attendee[];
  teams: string[][]; // arrays of attendee ids
  seenWelcome: boolean;
}
