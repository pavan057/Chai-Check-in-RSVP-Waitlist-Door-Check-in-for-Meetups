import { describe, expect, it } from 'vitest';
import { parseRsvps } from './parse';
import { buildRoster, mergeRsvps } from './roster';
import { makeTeams } from './teams';
import { SAMPLE_CHAT } from './sample';
import { DEFAULT_STATE } from './store';

const settings = { ...DEFAULT_STATE.settings, capacity: 3 };

describe('parseRsvps', () => {
  it('reads WhatsApp exports, skips chatter, detects cancellations', () => {
    const r = parseRsvps(SAMPLE_CHAT);
    expect(r.find((x) => x.name === 'Ananya Rao')?.email).toBe('ananya.rao@example.com');
    expect(r.find((x) => x.name === 'Kiran Kumar' && !x.cancel)?.phone).toBe('9848012345');
    expect(r.some((x) => x.name === 'Sneha')).toBe(false); // question, not RSVP
    expect(r.find((x) => x.name === 'Kiran Kumar' && x.cancel)).toBeTruthy();
    expect(r.find((x) => x.email === 'rahul.m@example.com')?.role).toBe('ai/ml');
    expect(r.find((x) => x.email === 'rahul.m@example.com')?.phone).toBe('9988776655');
  });

  it('reads Android WhatsApp format', () => {
    const r = parseRsvps('12/10/2026, 17:30 - Meera: count me in meera@x.io designer');
    expect(r[0]).toMatchObject({ name: 'Meera', email: 'meera@x.io', role: 'design' });
    expect(new Date(r[0].rsvpAt!).getHours()).toBe(17);
  });

  it('reads Google Forms CSV', () => {
    const csv = 'Timestamp,Full name,Email address,Phone,Your role\n2026/10/12 10:00:00,priya sharma,Priya@Example.com,+91 98765 43210,Frontend\n';
    const r = parseRsvps(csv);
    expect(r).toHaveLength(1);
    expect(r[0]).toMatchObject({ name: 'Priya Sharma', email: 'priya@example.com', phone: '9876543210', role: 'frontend' });
  });

  it('reads plain one-per-line text', () => {
    const r = parseRsvps('Vikram Singh - vikram@example.com - backend\nLata, 9123456789');
    expect(r.map((x) => x.name)).toEqual(['Vikram Singh', 'Lata']);
  });
});

describe('roster', () => {
  it('dedupes, cancels, waitlists, and puts late RSVPs last', () => {
    const { attendees, cancelled } = mergeRsvps([], parseRsvps(SAMPLE_CHAT));
    expect(cancelled).toBe(1);
    expect(attendees.filter((a) => a.name === 'Ananya Rao')).toHaveLength(1);
    expect(attendees.find((a) => a.name === 'Ananya Rao')?.phone).toBe('9000011122');
    const rows = buildRoster(attendees, settings);
    const confirmed = rows.filter((r) => r.status === 'confirmed').map((r) => r.name);
    expect(confirmed).toEqual(['Ananya Rao', 'Sneha Reddy', 'Rahul']);
    const arjun = rows.find((r) => r.name === 'Arjun Varma')!;
    expect(arjun.late).toBe(true);
    expect(arjun.status).toBe('waitlist');
    expect(rows.filter((r) => r.status === 'waitlist').at(-1)?.name).toBe('Arjun Varma');
  });

  it('promotes the next waitlisted person when someone cancels', () => {
    const { attendees } = mergeRsvps([], parseRsvps(SAMPLE_CHAT));
    const again = mergeRsvps(attendees, parseRsvps('[16/10/26, 9:00 AM] Sneha Reddy: sorry, cancel my seat')).attendees;
    const confirmed = buildRoster(again, settings).filter((r) => r.status === 'confirmed').map((r) => r.name);
    expect(confirmed).toEqual(['Ananya Rao', 'Rahul', 'Farhan Ali']);
  });

  it('importing the same chat twice adds nobody', () => {
    const first = mergeRsvps([], parseRsvps(SAMPLE_CHAT)).attendees;
    const second = mergeRsvps(first, parseRsvps(SAMPLE_CHAT));
    expect(second.added).toBe(0);
    expect(second.attendees).toHaveLength(first.length);
  });
});

describe('teams', () => {
  it('puts everyone in exactly one team and spreads designers', () => {
    const people = Array.from({ length: 12 }, (_, i) => ({
      ...mergeRsvps([], [{ name: `P${i}`, email: `p${i}@x.io`, phone: '', role: i < 3 ? 'design' as const : 'backend' as const, rsvpAt: null, cancel: false }]).attendees[0],
    }));
    const teams = makeTeams(people, 4, 7);
    expect(teams).toHaveLength(3);
    expect(teams.flat().sort()).toEqual(people.map((p) => p.id).sort());
    for (const t of teams) expect(t.filter((id) => people.find((p) => p.id === id)!.role === 'design')).toHaveLength(1);
  });
});
