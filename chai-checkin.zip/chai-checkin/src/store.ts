import { useEffect, useState } from 'react';
import type { AppState } from './types';

const KEY = 'chai-checkin:v1';

export const DEFAULT_STATE: AppState = {
  settings: {
    name: 'Chai & Commits',
    date: 'Sat 24 Oct 2026 · 6–9 PM IST (doors 5:30)',
    venue: 'CMR Institute of Technology, Medchal Road, Hyderabad',
    capacity: 40,
    deadline: '2026-10-21T23:59',
    teamSize: 4,
    geminiKey: '',
    geminiModel: 'gemini-2.5-flash',
  },
  attendees: [],
  teams: [],
  seenWelcome: false,
};

function load(): AppState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_STATE;
    const parsed = JSON.parse(raw) as Partial<AppState>;
    return {
      ...DEFAULT_STATE,
      ...parsed,
      settings: { ...DEFAULT_STATE.settings, ...(parsed.settings ?? {}) },
    };
  } catch {
    return DEFAULT_STATE;
  }
}

export function usePersistentState() {
  const [state, setState] = useState<AppState>(load);
  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* storage full or blocked */ }
  }, [state]);
  return [state, setState] as const;
}
